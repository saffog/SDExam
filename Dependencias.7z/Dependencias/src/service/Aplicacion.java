package service;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

import model.Nodo;

public class Aplicacion {

	private static Nodo coincide = null;
	
	public static void main(String[] args) {
		String linea = "";
		Scanner scan = new Scanner(System.in);
		linea = scan.nextLine();
		Nodo raiz = new Nodo();
		Collection<Nodo> arbol = new ArrayList<Nodo>();
		while(!linea.equals("END")){
			System.out.println(linea);
			if(linea != null && linea.trim().replaceAll(" ", "").length()>0){
				if(linea.contains("DEPEND")){
					String[] contenido = linea.split("\\s");
					for (String palabra : contenido) {
						if(palabra.trim().replaceAll(" ", "").length()>0 && !palabra.equals("DEPEND")){
							if(raiz.getDato() == null){
								raiz.setDato(palabra);
								arbol.add(raiz);
							}else{
								buscarNodo(raiz, palabra);
								if(coincide == null){
									if(raiz.getIzq() == null){
										raiz.setIzq(new Nodo(palabra));
									}else if(raiz.getDer() == null){
										raiz.setDer(new Nodo(palabra));
									}
								}else{
									if(coincide.getIzq() == null){
										coincide.setIzq(new Nodo(palabra));
									}else if(coincide.getDer() == null){
										coincide.setDer(new Nodo(palabra));
									}
									coincide = null;
								}
								
							}
						}
					}										
				}else if(linea.contains("INSTALL")){
					String[] contenido = linea.split("\\s");
					for (String palabra : contenido) {
						if(palabra.trim().replaceAll(" ", "").length()>0 && !palabra.equals("INSTALL")){
							buscarNodo(raiz, palabra);
							preInstall(coincide);
						}
					}
				}else if(linea.contains("REMOVE")){
					String[] contenido = linea.split("\\s");
					for (String palabra : contenido) {
						if(palabra.trim().replaceAll(" ", "").length()>0 && !palabra.equals("REMOVE")){
							coincide = null;
							buscarNodo(raiz, palabra);
							if(coincide != null){
								if(coincide.getDer() != null || coincide.getIzq() != null){
									System.out.println(palabra+" is still needed");
								}else{
									System.out.println("Removing "+palabra);
								}
							}else{
								System.out.println("Removing "+palabra);
							}
						}
					}
				}else if(linea.contains("LIST")){
					preOrden(raiz);
				}else{
					System.out.println("no tiene nada");
				}
			}
			linea = scan.nextLine();
		}
//		preOrden(raiz);
		System.out.println("END");
	}
	
	private static void preOrden(Nodo nodo){
		if(nodo != null && nodo.getDato() != null){
			System.out.println(" "+nodo.getDato());
			if(nodo.getIzq()!=null){
				preOrden(nodo.getIzq());
			}
			if(nodo.getDer()!=null){
				preOrden(nodo.getDer());
			}			
		}		
	}
	
	private static void preInstall(Nodo nodo){
		if(nodo != null && nodo.getDato() != null){
			if(nodo.getIzq()!=null){
				System.out.println("   Installing "+nodo.getIzq().getDato());
			}
			if(nodo.getDer()!=null){
				System.out.println("   Installing "+nodo.getDer().getDato());
			}			
		}		
	}
	
	private static void buscarNodo(Nodo nodo, String nombre){
		if(nodo != null && nodo.getDato() != null){
			if(nodo.getDato().equals(nombre)){
				coincide = nodo;
			}
			if(nodo.getIzq()!=null){
				buscarNodo(nodo.getIzq(), nombre);
			}
			if(nodo.getDer()!=null){
				buscarNodo(nodo.getDer(), nombre);
			}			
		}
	}
	
}
